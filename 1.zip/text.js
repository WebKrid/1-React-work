import React from 'react';

const Text = (props) => {
   return (
      <h1 style={style}>
          {props.Text}
      </h1>
   );
};

export default Text;