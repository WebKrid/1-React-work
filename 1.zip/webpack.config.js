import Text from "./text";
import './index.css';
const text = Text; 
const Message = () => {
  return (
    <div style={style}>
  <h1>Добро пожаловать {props.Text} </h1>
    </div>
  );
}; 